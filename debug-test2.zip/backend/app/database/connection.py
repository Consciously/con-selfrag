"""
Database connection utilities.
"""
