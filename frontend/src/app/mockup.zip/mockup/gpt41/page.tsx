// app/page.tsx or pages/index.tsx

import {
	FileText,
	BookOpen,
	MessageCircle,
	Settings,
	BarChart2,
	Search,
	User,
	Circle,
	CheckCircle,
	Loader2,
	UploadCloud,
	Info,
} from 'lucide-react';

export default function DashboardMockup() {
	return (
		<div className='flex min-h-screen bg-gray-50'>
			{/* Sidebar */}
			<aside className='w-64 bg-white border-r flex flex-col'>
				<div className='h-16 flex items-center justify-center border-b'>
					<span className='text-xl font-bold tracking-tight'>
						RAG Dashboard
					</span>
				</div>
				<nav className='flex-1 py-4'>
					<ul className='space-y-2'>
						<li>
							<a
								href='#'
								className='flex items-center px-6 py-2 text-gray-700 hover:bg-gray-100 rounded transition'
							>
								<MessageCircle className='w-5 h-5 mr-3' />
								Chat/Query
							</a>
						</li>
						<li>
							<a
								href='#'
								className='flex items-center px-6 py-2 text-gray-700 hover:bg-gray-100 rounded transition'
							>
								<FileText className='w-5 h-5 mr-3' />
								Document Library
							</a>
						</li>
						<li>
							<a
								href='#'
								className='flex items-center px-6 py-2 text-gray-700 hover:bg-gray-100 rounded transition'
							>
								<BookOpen className='w-5 h-5 mr-3' />
								Knowledge Bases
							</a>
						</li>
						<li>
							<a
								href='#'
								className='flex items-center px-6 py-2 text-gray-700 hover:bg-gray-100 rounded transition'
							>
								<Settings className='w-5 h-5 mr-3' />
								Settings
							</a>
						</li>
						<li>
							<a
								href='#'
								className='flex items-center px-6 py-2 text-gray-700 hover:bg-gray-100 rounded transition'
							>
								<BarChart2 className='w-5 h-5 mr-3' />
								Analytics/Logs
							</a>
						</li>
					</ul>
				</nav>
			</aside>

			{/* Main Content */}
			<div className='flex-1 flex flex-col'>
				{/* Header */}
				<header className='h-16 bg-white border-b flex items-center px-6 justify-between'>
					<div className='flex items-center gap-4'>
						<div className='relative'>
							<Search className='absolute left-3 top-2.5 w-4 h-4 text-gray-400' />
							<input
								type='text'
								placeholder='Search...'
								className='pl-10 pr-4 py-2 border rounded bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500'
							/>
						</div>
					</div>
					<div className='flex items-center gap-6'>
						<div className='flex items-center gap-2'>
							<Circle className='w-3 h-3 text-green-500' />
							<span className='text-xs text-gray-500'>System Online</span>
						</div>
						<User className='w-6 h-6 text-gray-600' />
					</div>
				</header>

				{/* Main Grid */}
				<main className='flex-1 p-8 grid grid-cols-3 gap-8'>
					{/* Chat Interface */}
					<section className='col-span-2 bg-white rounded-lg shadow p-6 flex flex-col'>
						<div className='flex-1 flex flex-col'>
							<div className='flex items-center mb-4'>
								<MessageCircle className='w-5 h-5 mr-2 text-blue-500' />
								<h2 className='text-lg font-semibold'>Chat / Query</h2>
							</div>
							{/* Conversation History */}
							<div className='flex-1 overflow-y-auto space-y-4 mb-4'>
								<div className='flex items-start gap-2'>
									<User className='w-5 h-5 text-gray-400 mt-1' />
									<div>
										<div className='bg-gray-100 rounded px-4 py-2'>
											What is the summary of document X?
										</div>
										<div className='text-xs text-gray-400 mt-1'>
											You • 2m ago
										</div>
									</div>
								</div>
								<div className='flex items-start gap-2'>
									<Info className='w-5 h-5 text-blue-400 mt-1' />
									<div>
										<div className='bg-blue-50 rounded px-4 py-2'>
											<div>
												<span className='font-semibold'>RAG:</span> Document X
												discusses...
											</div>
											<div className='mt-2 flex items-center gap-2 text-xs text-gray-500'>
												<CheckCircle className='w-4 h-4 text-green-500' />
												Confidence: 92%
												<a href='#' className='ml-2 underline text-blue-500'>
													[Source]
												</a>
											</div>
										</div>
										<div className='text-xs text-gray-400 mt-1'>
											System • 1m ago
										</div>
									</div>
								</div>
							</div>
							{/* Query Input */}
							<form className='flex gap-2'>
								<input
									type='text'
									placeholder='Type your question...'
									className='flex-1 border rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500'
								/>
								<button
									type='submit'
									className='bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition'
								>
									Send
								</button>
							</form>
						</div>
					</section>

					{/* Side Panel: Document Management */}
					<section className='bg-white rounded-lg shadow p-6 flex flex-col gap-6'>
						{/* Upload Area */}
						<div>
							<div className='flex items-center mb-2'>
								<UploadCloud className='w-5 h-5 mr-2 text-purple-500' />
								<h3 className='font-semibold'>Upload Documents</h3>
							</div>
							<div className='border-2 border-dashed border-gray-300 rounded-lg p-4 flex flex-col items-center justify-center text-gray-400 hover:border-blue-400 transition cursor-pointer'>
								<UploadCloud className='w-8 h-8 mb-2' />
								<span>Drag & drop files or click to upload</span>
							</div>
						</div>
						{/* Document List */}
						<div>
							<div className='flex items-center mb-2'>
								<FileText className='w-5 h-5 mr-2 text-green-500' />
								<h3 className='font-semibold'>Recent Documents</h3>
							</div>
							<ul className='space-y-2'>
								<li className='flex items-center justify-between'>
									<span className='truncate'>report.pdf</span>
									<span className='flex items-center gap-1 text-xs text-gray-500'>
										<Loader2 className='w-3 h-3 animate-spin' />
										Processing
									</span>
								</li>
								<li className='flex items-center justify-between'>
									<span className='truncate'>summary.txt</span>
									<span className='flex items-center gap-1 text-xs text-green-600'>
										<CheckCircle className='w-3 h-3' />
										Ready
									</span>
								</li>
							</ul>
						</div>
						{/* Knowledge Base Manager */}
						<div>
							<div className='flex items-center mb-2'>
								<BookOpen className='w-5 h-5 mr-2 text-orange-500' />
								<h3 className='font-semibold'>Knowledge Bases</h3>
							</div>
							<ul className='space-y-1'>
								<li className='flex items-center justify-between'>
									<span>General Docs</span>
									<span className='text-xs text-gray-400'>12 docs</span>
								</li>
								<li className='flex items-center justify-between'>
									<span>Research</span>
									<span className='text-xs text-gray-400'>5 docs</span>
								</li>
							</ul>
							<button className='mt-2 w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-1 rounded text-sm'>
								+ New Collection
							</button>
						</div>
					</section>
				</main>
			</div>
		</div>
	);
}
