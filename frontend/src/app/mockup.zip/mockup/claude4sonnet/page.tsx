'use client';

import React, { useState } from 'react';
import {
	MessageSquare,
	FileText,
	Database,
	Settings,
	BarChart3,
	Search,
	User,
	Wifi,
	Upload,
	Send,
	ExternalLink,
	Filter,
	MoreVertical,
	Plus,
	Clock,
	CheckCircle,
	AlertCircle,
	Loader,
} from 'lucide-react';

export default function RAGDashboard() {
	const [activeTab, setActiveTab] = useState<
		'chat' | 'documents' | 'knowledge' | 'settings' | 'analytics'
	>('chat');
	const [query, setQuery] = useState('');

	const sidebarItems: {
		id: 'chat' | 'documents' | 'knowledge' | 'settings' | 'analytics';
		label: string;
		icon: React.ComponentType<{ className?: string }>;
	}[] = [
		{ id: 'chat', label: 'Chat Interface', icon: MessageSquare },
		{ id: 'documents', label: 'Document Library', icon: FileText },
		{ id: 'knowledge', label: 'Knowledge Bases', icon: Database },
		{ id: 'settings', label: 'Settings', icon: Settings },
		{ id: 'analytics', label: 'Analytics', icon: BarChart3 },
	];

	const conversations: {
		id: number;
		type: 'user' | 'assistant';
		content: string;
		timestamp: string;
		sources?: string[];
		confidence?: number;
	}[] = [
		{
			id: 1,
			type: 'user',
			content: 'What are the key findings in the AI research paper?',
			timestamp: '2:35 PM',
		},
		{
			id: 2,
			type: 'assistant',
			content:
				'Based on the AI research paper, the key findings include: 1) Transformer models show 23% improvement in accuracy, 2) Training time reduced by 40% with new optimization techniques, 3) Memory usage decreased by 15% through efficient attention mechanisms.',
			timestamp: '2:36 PM',
			sources: ['AI Research Paper.pdf', 'Technical Documentation.pdf'],
			confidence: 0.92,
		},
	];

	const documents: {
		id: number;
		name: string;
		status: 'processed' | 'processing' | 'failed' | 'pending';
		size: string;
		uploaded: string;
	}[] = [
		{
			id: 1,
			name: 'AI Research Paper.pdf',
			status: 'processed',
			size: '2.4 MB',
			uploaded: '2 hours ago',
		},
		{
			id: 2,
			name: 'Company Guidelines.txt',
			status: 'processing',
			size: '156 KB',
			uploaded: '5 minutes ago',
		},
		{
			id: 3,
			name: 'Technical Documentation.pdf',
			status: 'failed',
			size: '5.1 MB',
			uploaded: '1 day ago',
		},
	];

	const StatusIcon = ({
		status,
	}: {
		status: 'processed' | 'processing' | 'failed' | 'pending';
	}) => {
		switch (status) {
			case 'processed':
				return <CheckCircle className='h-4 w-4 text-green-500' />;
			case 'processing':
				return <Loader className='h-4 w-4 text-blue-500 animate-spin' />;
			case 'failed':
				return <AlertCircle className='h-4 w-4 text-red-500' />;
			default:
				return <Clock className='h-4 w-4 text-gray-400' />;
		}
	};

	const renderContent = () => {
		switch (activeTab) {
			case 'chat':
				return (
					<div className='flex h-full'>
						{/* Chat Area */}
						<div className='flex-1 flex flex-col'>
							{/* Chat Header */}
							<div className='border-b border-gray-200 p-4'>
								<h2 className='text-lg font-semibold text-gray-900'>
									RAG Chat Interface
								</h2>
								<p className='text-sm text-gray-500'>
									Ask questions about your documents
								</p>
							</div>

							{/* Messages */}
							<div className='flex-1 overflow-y-auto p-4 space-y-4'>
								{conversations.map(msg => (
									<div
										key={msg.id}
										className={`flex ${
											msg.type === 'user' ? 'justify-end' : 'justify-start'
										}`}
									>
										<div
											className={`max-w-3xl rounded-lg p-4 ${
												msg.type === 'user'
													? 'bg-blue-600 text-white'
													: 'bg-gray-100 text-gray-900'
											}`}
										>
											<p className='text-sm'>{msg.content}</p>
											<div className='flex items-center justify-between mt-2'>
												<span className='text-xs opacity-70'>
													{msg.timestamp}
												</span>
												{msg.type === 'assistant' && (
													<span className='text-xs opacity-70'>
														Confidence:{' '}
														{typeof msg.confidence === 'number'
															? `${(msg.confidence * 100).toFixed(0)}%`
															: 'N/A'}
													</span>
												)}
											</div>
											{msg.sources && (
												<div className='mt-2 pt-2 border-t border-gray-300'>
													<p className='text-xs opacity-70 mb-1'>Sources:</p>
													<div className='flex flex-wrap gap-1'>
														{msg.sources.map((source, idx) => (
															<span
																key={idx}
																className='inline-flex items-center gap-1 text-xs bg-white bg-opacity-20 rounded px-2 py-1'
															>
																<ExternalLink className='h-3 w-3' />
																{source}
															</span>
														))}
													</div>
												</div>
											)}
										</div>
									</div>
								))}
							</div>

							{/* Input Area */}
							<div className='border-t border-gray-200 p-4'>
								<div className='flex gap-2'>
									<input
										type='text'
										value={query}
										onChange={e => setQuery(e.target.value)}
										placeholder='Ask a question about your documents...'
										className='flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500'
									/>
									<button className='bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors'>
										<Send className='h-4 w-4' />
									</button>
								</div>
							</div>
						</div>

						{/* Context Panel */}
						<div className='w-80 border-l border-gray-200 bg-gray-50'>
							<div className='p-4 border-b border-gray-200'>
								<h3 className='font-medium text-gray-900'>Context & Sources</h3>
							</div>
							<div className='p-4 space-y-4'>
								<div className='bg-white rounded-lg p-3 border'>
									<h4 className='text-sm font-medium text-gray-900 mb-2'>
										Retrieved Context
									</h4>
									<p className='text-xs text-gray-600'>
										"Transformer models demonstrate significant improvements in
										natural language processing tasks..."
									</p>
									<div className='mt-2 flex items-center gap-2'>
										<span className='text-xs text-gray-500'>Relevance:</span>
										<div className='flex-1 bg-gray-200 rounded-full h-1'>
											<div className='bg-green-500 h-1 rounded-full w-4/5'></div>
										</div>
										<span className='text-xs text-gray-500'>92%</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				);

			case 'documents':
				return (
					<div className='p-6'>
						{/* Header */}
						<div className='flex items-center justify-between mb-6'>
							<div>
								<h2 className='text-2xl font-bold text-gray-900'>
									Document Library
								</h2>
								<p className='text-gray-600'>
									Manage your knowledge base documents
								</p>
							</div>
							<button className='bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2'>
								<Upload className='h-4 w-4' />
								Upload Documents
							</button>
						</div>

						{/* Upload Area */}
						<div className='border-2 border-dashed border-gray-300 rounded-lg p-8 mb-6 text-center hover:border-gray-400 transition-colors'>
							<Upload className='h-12 w-12 text-gray-400 mx-auto mb-4' />
							<p className='text-lg font-medium text-gray-900 mb-2'>
								Drop files here or click to upload
							</p>
							<p className='text-gray-500'>
								Supports PDF, TXT, DOCX files up to 10MB
							</p>
						</div>

						{/* Documents Grid */}
						<div className='grid gap-4'>
							{documents.map(doc => (
								<div
									key={doc.id}
									className='bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow'
								>
									<div className='flex items-center justify-between'>
										<div className='flex items-center gap-3'>
											<FileText className='h-8 w-8 text-blue-500' />
											<div>
												<h3 className='font-medium text-gray-900'>
													{doc.name}
												</h3>
												<p className='text-sm text-gray-500'>
													{doc.size} • {doc.uploaded}
												</p>
											</div>
										</div>
										<div className='flex items-center gap-3'>
											<div className='flex items-center gap-2'>
												<StatusIcon status={doc.status} />
												<span className='text-sm capitalize text-gray-600'>
													{doc.status}
												</span>
											</div>
											<button className='text-gray-400 hover:text-gray-600'>
												<MoreVertical className='h-4 w-4' />
											</button>
										</div>
									</div>
								</div>
							))}
						</div>
					</div>
				);

			case 'knowledge':
				return (
					<div className='p-6'>
						<div className='flex items-center justify-between mb-6'>
							<div>
								<h2 className='text-2xl font-bold text-gray-900'>
									Knowledge Bases
								</h2>
								<p className='text-gray-600'>
									Organize documents into collections
								</p>
							</div>
							<button className='bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2'>
								<Plus className='h-4 w-4' />
								Create Collection
							</button>
						</div>

						<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'>
							{[
								{
									name: 'AI Research',
									docs: 12,
									lastUpdated: '2 hours ago',
									color: 'bg-blue-500',
								},
								{
									name: 'Company Policies',
									docs: 8,
									lastUpdated: '1 day ago',
									color: 'bg-green-500',
								},
								{
									name: 'Technical Docs',
									docs: 15,
									lastUpdated: '3 hours ago',
									color: 'bg-purple-500',
								},
							].map((kb, idx) => (
								<div
									key={idx}
									className='bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow'
								>
									<div className='flex items-center gap-3 mb-4'>
										<div className={`w-3 h-3 rounded-full ${kb.color}`}></div>
										<h3 className='font-semibold text-gray-900'>{kb.name}</h3>
									</div>
									<div className='space-y-2'>
										<div className='flex justify-between text-sm'>
											<span className='text-gray-500'>Documents:</span>
											<span className='font-medium'>{kb.docs}</span>
										</div>
										<div className='flex justify-between text-sm'>
											<span className='text-gray-500'>Last updated:</span>
											<span className='text-gray-700'>{kb.lastUpdated}</span>
										</div>
									</div>
								</div>
							))}
						</div>
					</div>
				);

			case 'settings':
				return (
					<div className='p-6'>
						<h2 className='text-2xl font-bold text-gray-900 mb-6'>Settings</h2>
						<div className='space-y-6'>
							<div className='bg-white border border-gray-200 rounded-lg p-6'>
								<h3 className='text-lg font-semibold text-gray-900 mb-4'>
									LLM Configuration
								</h3>
								<div className='space-y-4'>
									<div>
										<label className='block text-sm font-medium text-gray-700 mb-2'>
											Model Selection
										</label>
										<select className='w-full border border-gray-300 rounded-lg px-3 py-2'>
											<option>GPT-4</option>
											<option>Claude-3</option>
											<option>Llama-2</option>
										</select>
									</div>
									<div>
										<label className='block text-sm font-medium text-gray-700 mb-2'>
											Temperature
										</label>
										<input
											type='range'
											min='0'
											max='1'
											step='0.1'
											className='w-full'
										/>
									</div>
								</div>
							</div>

							<div className='bg-white border border-gray-200 rounded-lg p-6'>
								<h3 className='text-lg font-semibold text-gray-900 mb-4'>
									Vector Database
								</h3>
								<div className='space-y-4'>
									<div>
										<label className='block text-sm font-medium text-gray-700 mb-2'>
											Embedding Model
										</label>
										<select className='w-full border border-gray-300 rounded-lg px-3 py-2'>
											<option>text-embedding-ada-002</option>
											<option>sentence-transformers</option>
										</select>
									</div>
								</div>
							</div>
						</div>
					</div>
				);

			case 'analytics':
				return (
					<div className='p-6'>
						<h2 className='text-2xl font-bold text-gray-900 mb-6'>Analytics</h2>
						<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8'>
							{[
								{ label: 'Total Queries', value: '1,234', change: '+12%' },
								{ label: 'Documents', value: '45', change: '+3' },
								{ label: 'Avg Response Time', value: '1.2s', change: '-0.3s' },
								{ label: 'Success Rate', value: '94.2%', change: '+2.1%' },
							].map((stat, idx) => (
								<div
									key={idx}
									className='bg-white border border-gray-200 rounded-lg p-6'
								>
									<h3 className='text-sm font-medium text-gray-500'>
										{stat.label}
									</h3>
									<div className='flex items-baseline gap-2 mt-2'>
										<span className='text-2xl font-bold text-gray-900'>
											{stat.value}
										</span>
										<span className='text-sm text-green-600'>
											{stat.change}
										</span>
									</div>
								</div>
							))}
						</div>
					</div>
				);

			default:
				return null;
		}
	};

	return (
		<div className='h-screen bg-gray-50 flex'>
			{/* Sidebar */}
			<div className='w-64 bg-white border-r border-gray-200 flex flex-col'>
				{/* Logo */}
				<div className='p-6 border-b border-gray-200'>
					<h1 className='text-xl font-bold text-gray-900'>RAG System</h1>
				</div>

				{/* Navigation */}
				<nav className='flex-1 p-4'>
					<ul className='space-y-2'>
						{sidebarItems.map(item => {
							const Icon = item.icon;
							return (
								<li key={item.id}>
									<button
										onClick={() => setActiveTab(item.id)}
										className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
											activeTab === item.id
												? 'bg-blue-100 text-blue-700'
												: 'text-gray-600 hover:bg-gray-100'
										}`}
									>
										<Icon className='h-5 w-5' />
										<span className='font-medium'>{item.label}</span>
									</button>
								</li>
							);
						})}
					</ul>
				</nav>
			</div>

			{/* Main Content */}
			<div className='flex-1 flex flex-col'>
				{/* Header */}
				<header className='bg-white border-b border-gray-200 px-6 py-4'>
					<div className='flex items-center justify-between'>
						{/* Search */}
						<div className='flex-1 max-w-md'>
							<div className='relative'>
								<Search className='absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400' />
								<input
									type='text'
									placeholder='Search documents...'
									className='w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
								/>
							</div>
						</div>

						{/* Right side */}
						<div className='flex items-center gap-4'>
							<div className='flex items-center gap-2 text-sm text-gray-600'>
								<Wifi className='h-4 w-4 text-green-500' />
								<span>System Online</span>
							</div>
							<button className='p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100'>
								<User className='h-5 w-5' />
							</button>
						</div>
					</div>
				</header>

				{/* Content */}
				<main className='flex-1 overflow-hidden'>{renderContent()}</main>
			</div>
		</div>
	);
}
