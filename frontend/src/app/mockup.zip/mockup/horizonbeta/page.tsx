// app/page.tsx
'use client';

import { useState } from 'react';

type NavKey = 'chat' | 'documents' | 'knowledge' | 'settings' | 'analytics';

export default function DashboardMock() {
	const [active, setActive] = useState<NavKey>('chat');

	return (
		<div className='flex min-h-screen bg-gray-50 text-gray-900'>
			{/* Sidebar */}
			<aside className='hidden w-64 shrink-0 border-r border-gray-200 bg-white md:flex md:flex-col'>
				<div className='flex h-16 items-center gap-2 px-4'>
					<div className='h-8 w-8 rounded bg-indigo-600' />
					<span className='text-lg font-semibold'>RAG Dashboard</span>
				</div>
				<nav className='flex flex-1 flex-col gap-1 p-2'>
					<SidebarItem
						label='Chat / Query'
						active={active === 'chat'}
						onClick={() => setActive('chat')}
						icon={<IconChat />}
					/>
					<SidebarItem
						label='Document Library'
						active={active === 'documents'}
						onClick={() => setActive('documents')}
						icon={<IconDocs />}
					/>
					<SidebarItem
						label='Knowledge Bases'
						active={active === 'knowledge'}
						onClick={() => setActive('knowledge')}
						icon={<IconKB />}
					/>
					<SidebarItem
						label='Settings'
						active={active === 'settings'}
						onClick={() => setActive('settings')}
						icon={<IconSettings />}
					/>
					<SidebarItem
						label='Analytics / Logs'
						active={active === 'analytics'}
						onClick={() => setActive('analytics')}
						icon={<IconAnalytics />}
					/>
				</nav>
				<div className='border-t p-4'>
					<div className='flex items-center gap-3'>
						<div className='h-9 w-9 rounded-full bg-gray-200' />
						<div className='min-w-0'>
							<p className='truncate text-sm font-medium'>Jane Doe</p>
							<p className='truncate text-xs text-gray-500'>Admin</p>
						</div>
					</div>
				</div>
			</aside>

			{/* Main area */}
			<div className='flex min-w-0 flex-1 flex-col'>
				{/* Header */}
				<header className='sticky top-0 z-10 border-b border-gray-200 bg-white'>
					<div className='flex h-16 items-center gap-4 px-4'>
						<button
							className='inline-flex h-9 w-9 items-center justify-center rounded md:hidden'
							aria-label='Open menu'
							onClick={() => {
								// no-op in mock
							}}
						>
							<IconMenu />
						</button>
						<div className='relative max-w-xl flex-1'>
							<input
								placeholder='Search documents, messages, collections...'
								className='w-full rounded-md border border-gray-300 bg-white px-3 py-2 pr-9 text-sm outline-none ring-0 transition focus:border-indigo-500'
							/>
							<div className='pointer-events-none absolute inset-y-0 right-2 flex items-center text-gray-400'>
								<IconSearch />
							</div>
						</div>
						<div className='ml-auto flex items-center gap-3'>
							<StatusPill status='Operational' />
							<button className='inline-flex h-9 items-center justify-center rounded px-3 text-sm text-gray-700 hover:bg-gray-100'>
								Feedback
							</button>
						</div>
					</div>
				</header>

				{/* Content */}
				<main className='flex-1 p-4'>
					{active === 'chat' && <ChatMock />}
					{active === 'documents' && <DocumentsMock />}
					{active === 'knowledge' && <KnowledgeMock />}
					{active === 'settings' && <SettingsMock />}
					{active === 'analytics' && <AnalyticsMock />}
				</main>
			</div>
		</div>
	);
}

function SidebarItem(props: {
	label: string;
	active?: boolean;
	onClick?: () => void;
	icon?: React.ReactNode;
}) {
	const { label, active, onClick, icon } = props;
	return (
		<button
			onClick={onClick}
			className={[
				'flex items-center gap-3 rounded-md px-3 py-2 text-sm transition',
				active
					? 'bg-indigo-50 font-medium text-indigo-700'
					: 'text-gray-700 hover:bg-gray-100',
			].join(' ')}
		>
			<span className='text-gray-500'>{icon}</span>
			<span className='truncate'>{label}</span>
		</button>
	);
}

/* Chat / Query Interface */
function ChatMock() {
	return (
		<div className='grid gap-4 lg:grid-cols-3'>
			{/* Conversation + Input */}
			<div className='order-2 flex flex-col gap-4 lg:order-1 lg:col-span-2'>
				<div className='rounded-lg border border-gray-200 bg-white'>
					<div className='flex items-center justify-between border-b px-4 py-2'>
						<h2 className='text-sm font-semibold'>Conversation</h2>
						<div className='flex items-center gap-2 text-xs text-gray-500'>
							<span>Model:</span>
							<span className='rounded bg-gray-100 px-2 py-0.5'>
								gpt-4o-mini
							</span>
						</div>
					</div>
					<div className='max-h-[50vh] space-y-4 overflow-auto p-4'>
						<ChatBubble role='user' text='What is in the ACME Q3 report?' />
						<ChatBubble
							role='assistant'
							text='I found 3 relevant sections discussing revenue, churn, and product
              adoption in the ACME Q3 report.'
						/>
						<ChatBubble
							role='assistant'
							text='Revenue grew 12% QoQ, churn decreased to 3.1%, and weekly active
              users increased by 18%.'
						/>
					</div>
				</div>

				<div className='rounded-lg border border-gray-200 bg-white p-3'>
					<div className='flex items-start gap-2'>
						<textarea
							rows={3}
							className='min-h-[44px] w-full resize-y rounded-md border border-gray-300 px-3 py-2 text-sm outline-none transition focus:border-indigo-500'
							placeholder='Ask a question about your documents...'
						/>
						<button className='h-10 shrink-0 rounded-md bg-indigo-600 px-4 text-sm font-medium text-white hover:bg-indigo-700'>
							Send
						</button>
					</div>
					<div className='mt-2 flex items-center justify-between'>
						<div className='flex items-center gap-2 text-xs text-gray-500'>
							<label className='flex items-center gap-2'>
								<input type='checkbox' className='h-4 w-4' /> Show context
							</label>
							<label className='flex items-center gap-2'>
								<input type='checkbox' className='h-4 w-4' /> Show citations
							</label>
						</div>
						<div className='text-xs text-gray-500'>
							Enter to send • Shift+Enter for new line
						</div>
					</div>
				</div>
			</div>

			{/* Sources / Context */}
			<div className='order-1 flex flex-col gap-4 lg:order-2'>
				<div className='rounded-lg border border-gray-200 bg-white'>
					<div className='flex items-center justify-between border-b px-4 py-2'>
						<h3 className='text-sm font-semibold'>Source Citations</h3>
						<span className='text-xs text-gray-500'>Confidence: 0.86</span>
					</div>
					<ul className='divide-y'>
						{[
							'ACME_Q3.pdf#p12',
							'ACME_Q3.pdf#p18',
							'Product_Notes.txt#L120-150',
						].map((s, i) => (
							<li key={i} className='flex items-start gap-3 px-4 py-3'>
								<div className='mt-1 h-2.5 w-2.5 shrink-0 rounded-full bg-indigo-500' />
								<div className='min-w-0'>
									<p className='truncate text-sm font-medium'>{s}</p>
									<p className='line-clamp-2 text-xs text-gray-600'>
										“… revenue increased 12% QoQ driven by enterprise upsells
										and international expansion …”
									</p>
								</div>
							</li>
						))}
					</ul>
				</div>

				<div className='rounded-lg border border-gray-200 bg-white'>
					<div className='flex items-center justify-between border-b px-4 py-2'>
						<h3 className='text-sm font-semibold'>Context Viewer</h3>
						<button className='text-xs text-indigo-600 hover:underline'>
							Expand
						</button>
					</div>
					<div className='p-4 text-sm text-gray-700'>
						Chunked passages and highlights from retrieved documents will appear
						here.
					</div>
				</div>
			</div>
		</div>
	);
}

/* Document Management */
function DocumentsMock() {
	return (
		<div className='grid gap-4 lg:grid-cols-3'>
			<div className='lg:col-span-2'>
				<div className='rounded-lg border border-dashed border-gray-300 bg-white p-6'>
					<p className='text-sm font-medium'>Upload Documents</p>
					<p className='mt-1 text-xs text-gray-500'>
						Drag and drop files here or click to browse. Supports PDF, TXT, MD.
					</p>
					<div className='mt-4 flex items-center gap-3'>
						<button className='rounded-md border border-gray-300 bg-white px-3 py-2 text-sm hover:bg-gray-50'>
							Browse Files
						</button>
						<button className='rounded-md bg-indigo-600 px-3 py-2 text-sm font-medium text-white hover:bg-indigo-700'>
							Upload
						</button>
					</div>
				</div>

				<div className='mt-4 rounded-lg border border-gray-200 bg-white'>
					<div className='flex items-center justify-between border-b px-4 py-2'>
						<h3 className='text-sm font-semibold'>Documents</h3>
						<div className='flex items-center gap-2'>
							<select className='rounded-md border border-gray-300 bg-white px-2 py-1 text-xs'>
								<option>All</option>
								<option>Processing</option>
								<option>Ready</option>
								<option>Error</option>
							</select>
							<input
								className='rounded-md border border-gray-300 px-2 py-1 text-xs'
								placeholder='Filter...'
							/>
						</div>
					</div>
					<ul className='divide-y'>
						{[
							{ name: 'ACME_Q3.pdf', status: 'Ready', pages: 28 },
							{ name: 'Product_Notes.txt', status: 'Processing', pages: 0 },
							{ name: 'Contracts.pdf', status: 'Error', pages: 42 },
						].map((d, i) => (
							<li
								key={d.name}
								className='flex items-center justify-between px-4 py-3'
							>
								<div className='min-w-0'>
									<p className='truncate text-sm font-medium'>{d.name}</p>
									<p className='text-xs text-gray-500'>Pages: {d.pages}</p>
								</div>
								<StatusBadge
									status={d.status as 'Ready' | 'Processing' | 'Error'}
								/>
							</li>
						))}
					</ul>
				</div>
			</div>

			<div className='flex flex-col gap-4'>
				<div className='rounded-lg border border-gray-200 bg-white'>
					<div className='border-b px-4 py-2'>
						<h3 className='text-sm font-semibold'>Metadata</h3>
					</div>
					<div className='space-y-3 p-4 text-sm'>
						<KV label='Title' value='ACME_Q3.pdf' />
						<KV label='Uploaded' value='2025-07-12 10:44' />
						<KV label='Owner' value='Jane Doe' />
						<KV label='Tokens' value='~12,430' />
						<KV label='Embedding' value='text-embedding-3-large' />
					</div>
				</div>
				<div className='rounded-lg border border-gray-200 bg-white'>
					<div className='border-b px-4 py-2'>
						<h3 className='text-sm font-semibold'>Processing Status</h3>
					</div>
					<ul className='space-y-2 p-4 text-sm'>
						<Step label='Uploaded' done />
						<Step label='Chunked' done />
						<Step label='Embedded' inProgress />
						<Step label='Indexed' />
					</ul>
				</div>
			</div>
		</div>
	);
}

/* Knowledge Base Manager */
function KnowledgeMock() {
	return (
		<div className='grid gap-4 lg:grid-cols-3'>
			<div className='lg:col-span-2 rounded-lg border border-gray-200 bg-white'>
				<div className='flex items-center justify-between border-b px-4 py-2'>
					<h3 className='text-sm font-semibold'>Collections</h3>
					<button className='rounded-md bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-700'>
						New Collection
					</button>
				</div>
				<ul className='divide-y'>
					{[
						{ name: 'ACME Reports', docs: 24, size: '18.2 MB' },
						{ name: 'Product Notes', docs: 58, size: '9.3 MB' },
						{ name: 'Contracts', docs: 12, size: '32.1 MB' },
					].map((c, i) => (
						<li key={i} className='flex items-center justify-between px-4 py-3'>
							<div>
								<p className='text-sm font-medium'>{c.name}</p>
								<p className='text-xs text-gray-500'>
									{c.docs} documents • {c.size}
								</p>
							</div>
							<div className='flex items-center gap-2'>
								<button className='rounded-md border border-gray-300 bg-white px-2 py-1 text-xs hover:bg-gray-50'>
									Manage
								</button>
								<button className='rounded-md border border-gray-300 bg-white px-2 py-1 text-xs hover:bg-gray-50'>
									Assign Docs
								</button>
							</div>
						</li>
					))}
				</ul>
			</div>

			<div className='rounded-lg border border-gray-200 bg-white'>
				<div className='border-b px-4 py-2'>
					<h3 className='text-sm font-semibold'>Collection Stats</h3>
				</div>
				<div className='space-y-3 p-4 text-sm'>
					<KV label='Total Collections' value='3' />
					<KV label='Documents Indexed' value='94' />
					<KV label='Total Chunks' value='12,401' />
					<KV label='Avg. Response Time' value='820 ms' />
				</div>
			</div>
		</div>
	);
}

/* Settings Dashboard */
function SettingsMock() {
	return (
		<div className='grid gap-4 lg:grid-cols-2'>
			<div className='rounded-lg border border-gray-200 bg-white'>
				<div className='border-b px-4 py-2'>
					<h3 className='text-sm font-semibold'>LLM Configuration</h3>
				</div>
				<div className='space-y-3 p-4 text-sm'>
					<label className='block'>
						<span className='text-xs text-gray-600'>Model</span>
						<select className='mt-1 w-full rounded-md border border-gray-300 bg-white px-2 py-2 text-sm'>
							<option>gpt-4o-mini</option>
							<option>gpt-4.1</option>
							<option>claude-3-haiku</option>
						</select>
					</label>
					<div className='grid grid-cols-3 gap-3'>
						<label className='col-span-1'>
							<span className='text-xs text-gray-600'>Temperature</span>
							<input
								type='number'
								step='0.1'
								defaultValue={0.2}
								className='mt-1 w-full rounded-md border border-gray-300 px-2 py-2'
							/>
						</label>
						<label className='col-span-1'>
							<span className='text-xs text-gray-600'>Top P</span>
							<input
								type='number'
								step='0.1'
								defaultValue={0.9}
								className='mt-1 w-full rounded-md border border-gray-300 px-2 py-2'
							/>
						</label>
						<label className='col-span-1'>
							<span className='text-xs text-gray-600'>Max Tokens</span>
							<input
								type='number'
								defaultValue={1024}
								className='mt-1 w-full rounded-md border border-gray-300 px-2 py-2'
							/>
						</label>
					</div>
				</div>
			</div>

			<div className='rounded-lg border border-gray-200 bg-white'>
				<div className='border-b px-4 py-2'>
					<h3 className='text-sm font-semibold'>Embedding & Vector DB</h3>
				</div>
				<div className='space-y-3 p-4 text-sm'>
					<label className='block'>
						<span className='text-xs text-gray-600'>Embedding Model</span>
						<select className='mt-1 w-full rounded-md border border-gray-300 bg-white px-2 py-2 text-sm'>
							<option>text-embedding-3-large</option>
							<option>text-embedding-3-small</option>
							<option>e5-large</option>
						</select>
					</label>
					<label className='block'>
						<span className='text-xs text-gray-600'>Vector DB</span>
						<select className='mt-1 w-full rounded-md border border-gray-300 bg-white px-2 py-2 text-sm'>
							<option>Postgres/pgvector</option>
							<option>Pinecone</option>
							<option>Weaviate</option>
						</select>
					</label>
					<div className='grid grid-cols-2 gap-3'>
						<label>
							<span className='text-xs text-gray-600'>Index Name</span>
							<input
								className='mt-1 w-full rounded-md border border-gray-300 px-2 py-2'
								defaultValue='rag-index'
							/>
						</label>
						<label>
							<span className='text-xs text-gray-600'>Dimensionality</span>
							<input
								type='number'
								className='mt-1 w-full rounded-md border border-gray-300 px-2 py-2'
								defaultValue={3072}
							/>
						</label>
					</div>
				</div>
			</div>

			<div className='rounded-lg border border-gray-200 bg-white'>
				<div className='border-b px-4 py-2'>
					<h3 className='text-sm font-semibold'>API Keys</h3>
				</div>
				<div className='space-y-3 p-4 text-sm'>
					<label className='block'>
						<span className='text-xs text-gray-600'>OpenAI API Key</span>
						<input
							type='password'
							className='mt-1 w-full rounded-md border border-gray-300 px-2 py-2'
							defaultValue='sk-********'
						/>
					</label>
					<label className='block'>
						<span className='text-xs text-gray-600'>Pinecone API Key</span>
						<input
							type='password'
							className='mt-1 w-full rounded-md border border-gray-300 px-2 py-2'
							defaultValue='pc-********'
						/>
					</label>
					<div className='pt-1'>
						<button className='rounded-md bg-indigo-600 px-3 py-2 text-sm font-medium text-white hover:bg-indigo-700'>
							Save
						</button>
					</div>
				</div>
			</div>
		</div>
	);
}

/* Analytics / Logs */
function AnalyticsMock() {
	return (
		<div className='grid gap-4 lg:grid-cols-3'>
			<div className='rounded-lg border border-gray-200 bg-white lg:col-span-2'>
				<div className='flex items-center justify-between border-b px-4 py-2'>
					<h3 className='text-sm font-semibold'>Usage</h3>
					<select className='rounded-md border border-gray-300 bg-white px-2 py-1 text-xs'>
						<option>Last 24h</option>
						<option>Last 7d</option>
						<option>Last 30d</option>
					</select>
				</div>
				<div className='p-4'>
					<div className='h-40 w-full rounded-md border border-dashed border-gray-300 bg-gray-50' />
					<p className='mt-2 text-xs text-gray-500'>
						Placeholder for charts (requests, latency, costs).
					</p>
				</div>
			</div>
			<div className='rounded-lg border border-gray-200 bg-white'>
				<div className='border-b px-4 py-2'>
					<h3 className='text-sm font-semibold'>Recent Logs</h3>
				</div>
				<ul className='divide-y'>
					{[
						'Indexed 12 chunks from ACME_Q3.pdf',
						'Answer generated with 3 citations',
						'Embedding job started for Product_Notes.txt',
					].map((l, i) => (
						<li key={i} className='px-4 py-3 text-sm'>
							{l}
							<p className='text-xs text-gray-500'>2m ago</p>
						</li>
					))}
				</ul>
			</div>
		</div>
	);
}

/* UI helpers */
function ChatBubble(props: { role: 'user' | 'assistant'; text: string }) {
	const isUser = props.role === 'user';
	return (
		<div className={isUser ? 'flex justify-end' : 'flex justify-start'}>
			<div
				className={[
					'max-w-[75%] rounded-lg px-3 py-2 text-sm',
					isUser
						? 'bg-indigo-600 text-white'
						: 'bg-gray-100 text-gray-900 border border-gray-200',
				].join(' ')}
			>
				{props.text}
			</div>
		</div>
	);
}

function StatusPill(props: { status: 'Operational' | 'Degraded' | 'Down' }) {
	const color =
		props.status === 'Operational'
			? 'bg-green-500'
			: props.status === 'Degraded'
			? 'bg-yellow-500'
			: 'bg-red-500';
	return (
		<span className='inline-flex items-center gap-2 rounded-full bg-gray-100 px-2 py-1 text-xs'>
			<span className={`h-2 w-2 rounded-full ${color}`} />
			{props.status}
		</span>
	);
}

function StatusBadge(props: { status: 'Ready' | 'Processing' | 'Error' }) {
	const map: Record<'Ready' | 'Processing' | 'Error', string> = {
		Ready: 'bg-green-50 text-green-700 border-green-200',
		Processing: 'bg-yellow-50 text-yellow-700 border-yellow-200',
		Error: 'bg-red-50 text-red-700 border-red-200',
	};
	return (
		<span
			className={`rounded border px-2 py-0.5 text-xs font-medium ${
				map[props.status]
			}`}
		>
			{props.status}
		</span>
	);
}

function KV(props: { label: string; value: string }) {
	return (
		<div className='flex items-center justify-between gap-4'>
			<span className='text-xs text-gray-500'>{props.label}</span>
			<span className='truncate text-sm'>{props.value}</span>
		</div>
	);
}

function Step(props: { label: string; done?: boolean; inProgress?: boolean }) {
	const state = props.done ? 'done' : props.inProgress ? 'progress' : 'todo';
	const color =
		state === 'done'
			? 'bg-green-500'
			: state === 'progress'
			? 'bg-indigo-500'
			: 'bg-gray-300';
	return (
		<li className='flex items-center gap-3'>
			<span className={`h-2.5 w-2.5 rounded-full ${color}`} />
			<span className='text-sm'>{props.label}</span>
		</li>
	);
}

/* Icons (simple placeholders) */
function IconChat() {
	return (
		<svg
			className='h-4 w-4'
			viewBox='0 0 24 24'
			fill='none'
			stroke='currentColor'
		>
			<path
				d='M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v8z'
				strokeWidth='2'
			/>
		</svg>
	);
}
function IconDocs() {
	return (
		<svg
			className='h-4 w-4'
			viewBox='0 0 24 24'
			fill='none'
			stroke='currentColor'
		>
			<path d='M14 2H6a2 2 0 0 0-2 2v16l4-4h8a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z' />
		</svg>
	);
}
function IconKB() {
	return (
		<svg
			className='h-4 w-4'
			viewBox='0 0 24 24'
			fill='none'
			stroke='currentColor'
		>
			<path d='M4 19.5A2.5 2.5 0 0 1 6.5 17H20' />
			<path d='M4 4v15.5' />
			<path d='M20 2v15' />
			<path d='M8 7h8' />
			<path d='M8 11h8' />
		</svg>
	);
}
function IconSettings() {
	return (
		<svg
			className='h-4 w-4'
			viewBox='0 0 24 24'
			fill='none'
			stroke='currentColor'
		>
			<path d='M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z' />
			<path d='M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V22a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06A2 2 0 1 1 7.04 2.3l.06.06A1.65 1.65 0 0 0 8.92 2h.18A1.65 1.65 0 0 0 10.6 1.49V1.4a2 2 0 1 1 4 0v.09c0 .66.39 1.25 1 1.51.2.09.41.14.62.14h.18c.66 0 1.29.26 1.76.73l.06.06a2 2 0 1 1 2.83 2.83l-.06.06c-.47.47-.73 1.1-.73 1.76v.18c0 .21.05.42.14.62.26.61.85 1 1.51 1H22a2 2 0 1 1 0 4h-.09c-.66 0-1.25.39-1.51 1z' />
		</svg>
	);
}
function IconAnalytics() {
	return (
		<svg
			className='h-4 w-4'
			viewBox='0 0 24 24'
			fill='none'
			stroke='currentColor'
		>
			<path d='M3 3v18h18' />
			<path d='M7 13h2v5H7zM11 9h2v9h-2zM15 5h2v13h-2z' />
		</svg>
	);
}
function IconMenu() {
	return (
		<svg
			className='h-5 w-5'
			viewBox='0 0 24 24'
			fill='none'
			stroke='currentColor'
		>
			<path d='M3 6h18M3 12h18M3 18h18' />
		</svg>
	);
}
function IconSearch() {
	return (
		<svg
			className='h-4 w-4'
			viewBox='0 0 24 24'
			fill='none'
			stroke='currentColor'
		>
			<circle cx='11' cy='11' r='8' />
			<path d='m21 21-4.3-4.3' />
		</svg>
	);
}
