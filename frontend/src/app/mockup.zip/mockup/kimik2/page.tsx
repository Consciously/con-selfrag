// app/mockup/page.tsx
export default function MockupPage() {
	return (
		<div className='flex h-screen bg-slate-50 font-sans'>
			{/* Sidebar */}
			<aside className='w-64 shrink-0 border-r border-slate-200 bg-white flex flex-col'>
				<div className='p-4 border-b border-slate-200'>
					<h1 className='text-lg font-bold text-slate-800'>RAG Dashboard</h1>
				</div>

				<nav className='flex-1 p-4 space-y-2 text-sm'>
					<NavItem active label='Chat / Query' icon={<ChatIcon />} />
					<NavItem label='Document Library' icon={<FileIcon />} />
					<NavItem label='Knowledge Bases' icon={<FolderIcon />} />
					<NavItem label='Settings' icon={<SettingsIcon />} />
					<NavItem label='Analytics' icon={<ChartIcon />} />
				</nav>

				<div className='p-4 border-t border-slate-200'>
					<div className='flex items-center gap-2'>
						<div className='w-8 h-8 rounded-full bg-slate-200' />
						<div>
							<p className='font-medium text-slate-700'>User</p>
							<p className='text-xs text-slate-500'>user@example.com</p>
						</div>
					</div>
				</div>
			</aside>

			{/* Main */}
			<main className='flex-1 flex flex-col'>
				{/* Header */}
				<header className='h-16 border-b border-slate-200 bg-white flex items-center justify-between px-6'>
					<div className='relative w-full max-w-sm'>
						<SearchIcon className='absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400' />
						<input
							type='text'
							placeholder='Search documents...'
							className='w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500'
						/>
					</div>

					<div className='flex items-center gap-4'>
						<span className='text-xs text-green-600 font-medium'>
							● System OK
						</span>
						<BellIcon className='w-5 h-5 text-slate-500' />
					</div>
				</header>

				{/* Content */}
				<div className='flex-1 grid grid-cols-12 gap-6 p-6 overflow-y-auto'>
					{/* Left: Chat */}
					<section className='col-span-8 flex flex-col bg-white rounded-lg shadow-sm border border-slate-200'>
						<div className='p-4 border-b border-slate-200'>
							<h2 className='font-semibold text-slate-800'>Chat Interface</h2>
						</div>

						<div className='flex-1 p-4 space-y-4 overflow-y-auto'>
							<ChatBubble role='user' text='What is the capital of France?' />
							<ChatBubble
								role='assistant'
								text='The capital of France is Paris.'
								sources={[
									{ title: 'france_facts.pdf', page: 3 },
									{ title: 'europe_overview.txt', page: 1 },
								]}
							/>
						</div>

						<div className='p-4 border-t border-slate-200'>
							<div className='flex gap-2'>
								<input
									type='text'
									placeholder='Ask a question...'
									className='flex-1 px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500'
								/>
								<button className='px-4 py-2 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700'>
									Send
								</button>
							</div>
						</div>
					</section>

					{/* Right: Context */}
					<section className='col-span-4 flex flex-col bg-white rounded-lg shadow-sm border border-slate-200'>
						<div className='p-4 border-b border-slate-200'>
							<h2 className='font-semibold text-slate-800'>
								Retrieved Context
							</h2>
						</div>
						<div className='flex-1 p-4 space-y-3 overflow-y-auto text-sm text-slate-700'>
							<ContextCard
								title='france_facts.pdf'
								page={3}
								content='Paris is the capital and most populous city of France...'
							/>
							<ContextCard
								title='europe_overview.txt'
								page={1}
								content='France is a country located in Western Europe...'
							/>
						</div>
					</section>

					{/* Document Upload */}
					<section className='col-span-12 bg-white rounded-lg shadow-sm border border-slate-200 p-6'>
						<h3 className='font-semibold text-slate-800 mb-4'>
							Upload Documents
						</h3>
						<div className='border-2 border-dashed border-slate-300 rounded-lg p-8 text-center'>
							<UploadIcon className='mx-auto w-10 h-10 text-slate-400 mb-2' />
							<p className='text-sm text-slate-600'>
								Drag & drop files here or{' '}
								<button className='text-blue-600 underline'>browse</button>
							</p>
						</div>
					</section>
				</div>
			</main>
		</div>
	);
}

/* Reusable NavItem */
function NavItem({
	label,
	icon,
	active,
}: {
	label: string;
	icon: React.ReactNode;
	active?: boolean;
}) {
	return (
		<a
			href='#'
			className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors
        ${
					active
						? 'bg-blue-100 text-blue-700'
						: 'text-slate-600 hover:bg-slate-100'
				}`}
		>
			{icon}
			{label}
		</a>
	);
}

/* Chat bubble */
function ChatBubble({
	role,
	text,
	sources,
}: {
	role: 'user' | 'assistant';
	text: string;
	sources?: { title: string; page: number }[];
}) {
	return (
		<div
			className={`flex ${role === 'user' ? 'justify-end' : 'justify-start'}`}
		>
			<div
				className={`max-w-xl px-4 py-2 rounded-lg text-sm
          ${
						role === 'user'
							? 'bg-blue-600 text-white'
							: 'bg-slate-100 text-slate-800'
					}`}
			>
				<p>{text}</p>
				{sources && (
					<div className='mt-2 text-xs space-y-1'>
						{sources.map((s, i) => (
							<div key={i} className='text-blue-600'>
								{s.title} (p.{s.page})
							</div>
						))}
					</div>
				)}
			</div>
		</div>
	);
}

/* Context card */
function ContextCard({
	title,
	page,
	content,
}: {
	title: string;
	page: number;
	content: string;
}) {
	return (
		<div className='border border-slate-200 rounded-md p-3'>
			<p className='font-medium text-slate-800 text-xs'>
				{title} · Page {page}
			</p>
			<p className='mt-1 text-xs text-slate-600'>{content}</p>
		</div>
	);
}

/* SVG Icons (Heroicons outline) */
const ChatIcon = () => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		fill='none'
		viewBox='0 0 24 24'
		strokeWidth={1.5}
		stroke='currentColor'
		className='w-5 h-5'
	>
		<path
			strokeLinecap='round'
			strokeLinejoin='round'
			d='M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3.697-3.697C12.71 15.44 11.53 15 10.5 15h-5c-1.136 0-2.1-.847-2.193-1.98A15.75 15.75 0 013 13.186V8.903c0-1.136.847-2.1 1.98-2.193.34-.027.68-.052 1.02-.072V3h10.5v5.112c.34.02.68.045 1.02.072z'
		/>
	</svg>
);

const FileIcon = () => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		fill='none'
		viewBox='0 0 24 24'
		strokeWidth={1.5}
		stroke='currentColor'
		className='w-5 h-5'
	>
		<path
			strokeLinecap='round'
			strokeLinejoin='round'
			d='M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z'
		/>
	</svg>
);

const FolderIcon = () => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		fill='none'
		viewBox='0 0 24 24'
		strokeWidth={1.5}
		stroke='currentColor'
		className='w-5 h-5'
	>
		<path
			strokeLinecap='round'
			strokeLinejoin='round'
			d='M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z'
		/>
	</svg>
);

const SettingsIcon = () => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		fill='none'
		viewBox='0 0 24 24'
		strokeWidth={1.5}
		stroke='currentColor'
		className='w-5 h-5'
	>
		<path
			strokeLinecap='round'
			strokeLinejoin='round'
			d='M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.646.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 1.255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.333.183-.582.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-1.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z'
		/>
		<path
			strokeLinecap='round'
			strokeLinejoin='round'
			d='M15 12a3 3 0 11-6 0 3 3 0 016 0z'
		/>
	</svg>
);

const ChartIcon = () => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		fill='none'
		viewBox='0 0 24 24'
		strokeWidth={1.5}
		stroke='currentColor'
		className='w-5 h-5'
	>
		<path
			strokeLinecap='round'
			strokeLinejoin='round'
			d='M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z'
		/>
	</svg>
);

const SearchIcon = ({ className }: { className?: string }) => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		fill='none'
		viewBox='0 0 24 24'
		strokeWidth={1.5}
		stroke='currentColor'
		className={className}
	>
		<path
			strokeLinecap='round'
			strokeLinejoin='round'
			d='M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z'
		/>
	</svg>
);

const BellIcon = ({ className }: { className?: string }) => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		fill='none'
		viewBox='0 0 24 24'
		strokeWidth={1.5}
		stroke='currentColor'
		className={className}
	>
		<path
			strokeLinecap='round'
			strokeLinejoin='round'
			d='M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0'
		/>
	</svg>
);

const UploadIcon = ({ className }: { className?: string }) => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		fill='none'
		viewBox='0 0 24 24'
		strokeWidth={1.5}
		stroke='currentColor'
		className={className}
	>
		<path
			strokeLinecap='round'
			strokeLinejoin='round'
			d='M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5'
		/>
	</svg>
);
