'use client'; // This directive is crucial for Client Components in Next.js App Router

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation'; // For Next.js App Router hooks
import {
	MessageSquare,
	FileText,
	Boxes,
	Settings,
	BarChart2,
	UploadCloud,
} from 'lucide-react'; // Assuming lucide-react for icons

// --- Sidebar Component (Internal) ---
const Sidebar = ({
	activePath,
	onNavigate,
}: {
	activePath: string;
	onNavigate: (path: string) => void;
}) => {
	const navItems = [
		{
			name: 'Chat/Query',
			icon: <MessageSquare className='w-5 h-5 mr-3' />,
			path: '/',
		},
		{
			name: 'Document Library',
			icon: <FileText className='w-5 h-5 mr-3' />,
			path: '/documents',
		},
		{
			name: 'Knowledge Bases',
			icon: <Boxes className='w-5 h-5 mr-3' />,
			path: '/knowledge-bases',
		},
		{
			name: 'Settings',
			icon: <Settings className='w-5 h-5 mr-3' />,
			path: '/settings',
		},
		{
			name: 'Analytics/Logs',
			icon: <BarChart2 className='w-5 h-5 mr-3' />,
			path: '/analytics',
		},
	];

	return (
		<aside className='w-64 bg-gray-800 text-white flex flex-col p-4'>
			<div className='text-2xl font-bold mb-8'>RAG Dashboard</div>
			<nav className='flex-grow'>
				<ul>
					{navItems.map(item => (
						<li key={item.path} className='mb-2'>
							<Link
								href={item.path}
								onClick={() => onNavigate(item.path)}
								className={`flex items-center p-2 rounded-md transition-colors ${
									activePath === item.path
										? 'bg-blue-600 hover:bg-blue-700'
										: 'hover:bg-gray-700'
								}`}
							>
								{item.icon}
								{item.name}
							</Link>
						</li>
					))}
				</ul>
			</nav>
		</aside>
	);
};

// --- Header Component (Internal) ---
const Header = () => {
	return (
		<header className='bg-white shadow-md p-4 flex items-center justify-between z-10'>
			<div className='flex items-center flex-grow'>
				<input
					type='text'
					placeholder='Global Search...'
					className='border border-gray-300 rounded-md py-2 px-4 w-1/2 focus:outline-none focus:ring-2 focus:ring-blue-500'
				/>
			</div>
			<div className='flex items-center space-x-4 ml-auto'>
				<div className='relative'>
					<div className='w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold cursor-pointer'>
						JD
					</div>
					<span className='absolute bottom-0 right-0 block h-2 w-2 rounded-full ring-2 ring-white bg-green-400'></span>
				</div>
				<div className='flex items-center space-x-2 text-sm text-gray-600'>
					<span className='font-medium'>System Status:</span>
					<span className='text-green-500'>Online</span>
					<span className='w-2 h-2 rounded-full bg-green-500'></span>
				</div>
			</div>
		</header>
	);
};

// --- ChatInterface Component (Internal) ---
const ChatInterface = () => {
	return (
		<section className='bg-white rounded-lg shadow-md p-6 h-full flex flex-col'>
			<h2 className='text-2xl font-semibold mb-4'>Chat Interface</h2>
			<div className='flex flex-col md:flex-row gap-6 flex-grow'>
				{/* Conversation History + Query Input */}
				<div className='flex-1 flex flex-col border rounded-lg p-4'>
					<div className='flex-grow overflow-y-auto mb-4 border-b pb-4'>
						<div className='mb-2 text-gray-700'>
							<span className='font-bold'>You:</span> What is the capital of
							France?
						</div>
						<div className='mb-2 text-blue-800 bg-blue-50 p-2 rounded-md'>
							<span className='font-bold'>RAG Bot:</span> The capital of France
							is Paris.
							<p className='text-xs text-gray-500 mt-1'>
								(Confidence: 0.95){' '}
								<a href='#' className='underline ml-2'>
									Source 1
								</a>
								,
								<a href='#' className='underline ml-1'>
									Source 2
								</a>
							</p>
						</div>
						<div className='mb-2 text-gray-700'>
							<span className='font-bold'>You:</span> Tell me about the document
							&quot;Annual Report 2023.pdf&quot;.
						</div>
						<div className='mb-2 text-blue-800 bg-blue-50 p-2 rounded-md'>
							<span className='font-bold'>RAG Bot:</span> The &quot;Annual
							Report 2023.pdf&quot; discusses the company&apos;s financial
							performance, strategic initiatives, and market outlook for the
							year 2023. Key highlights include a 15% revenue increase and
							expansion into new markets.
							<p className='text-xs text-gray-500 mt-1'>
								(Confidence: 0.92){' '}
								<a href='#' className='underline ml-2'>
									Source: Annual Report 2023.pdf
								</a>
							</p>
						</div>
					</div>
					<div className='flex'>
						<input
							type='text'
							placeholder='Ask your question...'
							className='flex-grow border border-gray-300 rounded-l-md py-2 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500'
						/>
						<button className='bg-blue-600 text-white px-6 py-2 rounded-r-md hover:bg-blue-700 transition-colors'>
							Send
						</button>
					</div>
				</div>

				{/* Source Citation Panel + Context Viewer */}
				<div className='w-full md:w-1/3 border rounded-lg p-4 bg-gray-50 flex flex-col'>
					<h3 className='text-lg font-semibold mb-3'>Retrieved Context</h3>
					<div className='overflow-y-auto flex-grow'>
						<div className='mb-4 p-3 bg-white rounded-md shadow-sm'>
							<p className='font-medium text-sm text-gray-800'>
								Source: Document A - Page 3
							</p>
							<p className='text-gray-600 text-sm mt-1'>
								&quot;...Paris, the capital of France, is a major European city
								and a global center for art, fashion, gastronomy and
								culture...&quot;
							</p>
							<button className='text-blue-500 text-xs mt-1 hover:underline'>
								Expand Context
							</button>
						</div>
						<div className='mb-4 p-3 bg-white rounded-md shadow-sm'>
							<p className='font-medium text-sm text-gray-800'>
								Source: Annual Report 2023.pdf - Section 2.1
							</p>
							<p className='text-gray-600 text-sm mt-1'>
								&quot;...The company reported a substantial increase in its
								annual revenue by 15% compared to the previous fiscal year,
								primarily driven by successful product launches and strategic
								market entries in Q3...&quot;
							</p>
							<button className='text-blue-500 text-xs mt-1 hover:underline'>
								Expand Context
							</button>
						</div>
					</div>
				</div>
			</div>
		</section>
	);
};

// --- DocumentManagement Component (Internal) ---
const DocumentManagement = () => {
	return (
		<section className='bg-white rounded-lg shadow-md p-6 h-full flex flex-col'>
			<h2 className='text-2xl font-semibold mb-4'>Document Management</h2>
			<div
				className='border-2 border-dashed border-gray-300 rounded-lg p-8 text-center text-gray-500
                   hover:border-blue-500 hover:text-blue-500 transition-colors cursor-pointer'
			>
				<UploadCloud className='w-12 h-12 mx-auto mb-4' />
				<p className='mb-2'>Drag and drop your documents here, or</p>
				<button className='bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors'>
					Browse Files
				</button>
				<p className='text-sm mt-2'>
					Supported formats: PDF, TXT, DOCX, MD, etc.
				</p>
			</div>

			<div className='mt-8 flex-grow overflow-y-auto'>
				<h3 className='text-lg font-semibold mb-3'>Uploaded Documents</h3>
				<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4'>
					<div className='bg-gray-50 p-4 rounded-md shadow-sm'>
						<p className='font-medium'>Annual Report 2023.pdf</p>
						<p className='text-sm text-gray-600'>Status: Processed</p>
						<p className='text-xs text-gray-500'>Size: 2.3 MB</p>
						<p className='text-xs text-gray-500'>Uploaded: 2024-01-15</p>
						<button className='text-blue-500 text-sm mt-2 hover:underline'>
							View Metadata
						</button>
					</div>
					<div className='bg-gray-50 p-4 rounded-md shadow-sm'>
						<p className='font-medium'>Company Policy.docx</p>
						<p className='text-sm text-orange-600'>Status: Processing...</p>
						<p className='text-xs text-gray-500'>Size: 1.1 MB</p>
						<p className='text-xs text-gray-500'>Uploaded: 2024-01-18</p>
						<button className='text-blue-500 text-sm mt-2 hover:underline'>
							View Status
						</button>
					</div>
				</div>
			</div>
		</section>
	);
};

// --- SettingsDashboard Component (Internal) ---
const SettingsDashboard = () => {
	return (
		<section className='bg-white rounded-lg shadow-md p-6 h-full flex flex-col'>
			<h2 className='text-2xl font-semibold mb-4'>Settings Dashboard</h2>
			<div className='grid grid-cols-1 md:grid-cols-2 gap-6 flex-grow overflow-y-auto'>
				<div>
					<h3 className='text-lg font-semibold mb-2'>
						LLM Model Configuration
					</h3>
					<label
						htmlFor='llm-model'
						className='block text-gray-700 text-sm mb-1'
					>
						Select Model:
					</label>
					<select
						id='llm-model'
						className='border border-gray-300 rounded-md py-2 px-3 w-full mb-3 focus:outline-none focus:ring-2 focus:ring-blue-500'
					>
						<option>Gemini 2.5 Flash</option>
						<option>OpenAI GPT-4</option>
						<option>Llama 3</option>
					</select>
					<label
						htmlFor='temperature'
						className='block text-gray-700 text-sm mb-1'
					>
						Temperature:
					</label>
					<input
						type='range'
						id='temperature'
						min='0'
						max='1'
						step='0.1'
						defaultValue='0.7'
						className='w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mb-1'
					/>
					<span className='text-sm text-gray-600'>Value: 0.7</span>
				</div>
				<div>
					<h3 className='text-lg font-semibold mb-2'>Vector DB Settings</h3>
					<label
						htmlFor='vector-db-type'
						className='block text-gray-700 text-sm mb-1'
					>
						Database Type:
					</label>
					<select
						id='vector-db-type'
						className='border border-gray-300 rounded-md py-2 px-3 w-full mb-3 focus:outline-none focus:ring-2 focus:ring-blue-500'
					>
						<option>Pinecone</option>
						<option>Weaviate</option>
						<option>Chroma</option>
					</select>
					<label htmlFor='api-key' className='block text-gray-700 text-sm mb-1'>
						API Key:
					</label>
					<input
						type='password'
						id='api-key'
						defaultValue='••••••••••••••••'
						className='border border-gray-300 rounded-md py-2 px-3 w-full mb-3 focus:outline-none focus:ring-2 focus:ring-blue-500'
					/>
					<button className='bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors'>
						Save Settings
					</button>
				</div>
			</div>
		</section>
	);
};

// --- Main Page Component ---
export default function DashboardPage() {
	const router = useRouter();
	const pathname = usePathname(); // Get the current path from Next.js

	const renderContent = () => {
		switch (pathname) {
			case '/documents':
				return <DocumentManagement />;
			case '/settings':
				return <SettingsDashboard />;
			case '/': // Default route
			default:
				return <ChatInterface />;
		}
	};

	return (
		<div className='flex h-screen bg-gray-100 font-sans antialiased'>
			{/* Sidebar */}
			<Sidebar activePath={pathname} onNavigate={path => router.push(path)} />

			{/* Main Content Area */}
			<div className='flex-1 flex flex-col'>
				{/* Header */}
				<Header />

				{/* Dynamic Main Content */}
				<main className='flex-1 p-6 overflow-auto'>{renderContent()}</main>
			</div>
		</div>
	);
}
