// app/page.tsx
import {
	Brain,
	BookOpen,
	Folder,
	Settings,
	Search,
	User,
	Zap,
	FileText,
	CheckCircle,
	AlertTriangle,
	Send,
} from 'lucide-react';

export default function DashboardPage() {
	return (
		<div className='flex h-screen bg-gray-50 text-gray-900'>
			{/* Sidebar */}
			<aside className='w-64 bg-white border-r border-gray-200 flex flex-col'>
				<div className='p-6'>
					<div className='flex items-center space-x-2'>
						<Brain className='w-6 h-6 text-blue-600' />
						<span className='text-xl font-semibold'>RAGFlow</span>
					</div>
				</div>

				<nav className='flex-1 p-4 space-y-2'>
					<a
						href='#chat'
						className='flex items-center space-x-3 px-3 py-2 rounded-md bg-blue-50 text-blue-700 font-medium'
					>
						<Zap className='w-5 h-5' />
						<span>Chat</span>
					</a>
					<a
						href='#documents'
						className='flex items-center space-x-3 px-3 py-2 rounded-md hover:bg-gray-100 transition-colors'
					>
						<BookOpen className='w-5 h-5' />
						<span>Document Library</span>
					</a>
					<a
						href='#collections'
						className='flex items-center space-x-3 px-3 py-2 rounded-md hover:bg-gray-100 transition-colors'
					>
						<Folder className='w-5 h-5' />
						<span>Knowledge Bases</span>
					</a>
					<a
						href='#settings'
						className='flex items-center space-x-3 px-3 py-2 rounded-md hover:bg-gray-100 transition-colors'
					>
						<Settings className='w-5 h-5' />
						<span>Settings</span>
					</a>
				</nav>

				<div className='p-4 border-t border-gray-200'>
					<div className='flex items-center space-x-3 px-2 py-2 text-sm text-gray-600'>
						<User className='w-5 h-5' />
						<span>You</span>
					</div>
				</div>
			</aside>

			{/* Main Content */}
			<div className='flex-1 flex flex-col overflow-hidden'>
				{/* Header */}
				<header className='bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between'>
					<div className='flex items-center space-x-4'>
						<div className='relative'>
							<Search className='absolute left-3 top-1/2 w-4 h-4 -translate-y-1/2 text-gray-500' />
							<input
								type='text'
								placeholder='Search documents or queries...'
								className='pl-10 pr-4 py-2 w-80 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent'
							/>
						</div>
					</div>
					<div className='flex items-center space-x-4'>
						<div className='flex items-center space-x-1 text-sm text-green-600'>
							<div className='w-2 h-2 bg-green-500 rounded-full'></div>
							<span>System Ready</span>
						</div>
						<button className='p-2 text-gray-500 hover:bg-gray-100 rounded-lg'>
							<Settings className='w-5 h-5' />
						</button>
					</div>
				</header>

				{/* Page Content */}
				<main className='flex-1 overflow-y-auto p-6 bg-gray-50'>
					<div className='max-w-7xl mx-auto flex gap-6 h-full'>
						{/* Chat Panel (Left - 2/3) */}
						<div className='flex-2 flex flex-col bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden'>
							{/* Chat Header */}
							<div className='px-6 py-4 border-b border-gray-200 bg-gray-50'>
								<h1 className='text-lg font-semibold'>
									Ask Your Knowledge Base
								</h1>
								<p className='text-sm text-gray-600 mt-1'>
									Powered by RAG & LLM
								</p>
							</div>

							{/* Messages */}
							<div className='flex-1 p-6 overflow-y-auto space-y-6'>
								{/* Example User Message */}
								<div className='flex justify-end'>
									<div className='max-w-96 p-4 bg-blue-600 text-white rounded-2xl rounded-tr-none shadow'>
										<p className='text-sm'>
											What are the key findings in the climate change report?
										</p>
									</div>
								</div>

								{/* Example AI Response */}
								<div className='flex justify-start'>
									<div className='max-w-96 p-4 bg-white border border-gray-200 rounded-2xl rounded-tl-none shadow'>
										<p className='text-sm text-gray-800 mb-3'>
											The report highlights rising global temperatures,
											increased frequency of extreme weather events, and melting
											polar ice caps as key findings.
										</p>
										<div className='text-xs text-blue-600 underline mb-2'>
											Show sources
										</div>
										<div className='text-xs text-gray-500 flex items-center space-x-1'>
											<CheckCircle className='w-3 h-3 text-green-500' />
											<span>Confidence: High</span>
										</div>
									</div>
								</div>
							</div>

							{/* Input Area */}
							<div className='px-6 py-4 border-t border-gray-200 bg-gray-50'>
								<form className='flex space-x-2'>
									<input
										type='text'
										placeholder='Ask anything about your documents...'
										className='flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
									/>
									<button
										type='submit'
										className='p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors'
									>
										<Send className='w-5 h-5' />
									</button>
								</form>
							</div>
						</div>

						{/* Sidebar Panel (Right - 1/3) */}
						<div className='flex-1 flex flex-col bg-white rounded-xl shadow-sm border border-gray-200'>
							<div className='p-4 border-b border-gray-200'>
								<h2 className='text-md font-semibold'>Retrieved Context</h2>
								<p className='text-xs text-gray-600 mt-1'>From 3 documents</p>
							</div>

							<div className='flex-1 p-4 space-y-4 overflow-y-auto'>
								{[
									{ title: 'Climate_Report_2024.pdf', relevance: 'High' },
									{ title: 'IPCC_Summary.txt', relevance: 'High' },
									{
										title: 'Environmental_Impact_Q3.docx',
										relevance: 'Medium',
									},
								].map((doc, i) => (
									<div
										key={i}
										className='p-3 border border-gray-200 rounded-lg hover:shadow-sm transition-shadow bg-gray-50'
									>
										<div className='flex items-start space-x-2'>
											<FileText className='w-4 h-4 text-gray-500 mt-0.5' />
											<div className='text-xs'>
												<p className='font-medium text-gray-900'>{doc.title}</p>
												<p className='text-gray-500'>
													Relevance: {doc.relevance}
												</p>
												<button className='text-blue-600 hover:underline mt-1'>
													Preview
												</button>
											</div>
										</div>
									</div>
								))}
							</div>

							<div className='p-4 border-t border-gray-200 bg-gray-50 text-xs text-gray-500'>
								<div className='flex items-center space-x-1'>
									<AlertTriangle className='w-3 h-3 text-yellow-500' />
									<span>
										Context may contain inaccuracies. Verify critical info.
									</span>
								</div>
							</div>
						</div>
					</div>
				</main>
			</div>
		</div>
	);
}
