'use client';

import { useState } from 'react';
import {
	Home,
	FileText,
	Folder,
	Settings,
	BarChart2,
	Search,
	User,
	Bell,
	MessageSquare,
	Book,
	ChevronDown,
} from 'lucide-react';

export default function Dashboard() {
	const [activeNav, setActiveNav] = useState('chat');
	const [sidebarOpen, setSidebarOpen] = useState(true);

	const navItems = [
		{
			id: 'chat',
			label: 'Chat Interface',
			icon: <MessageSquare className='w-5 h-5' />,
		},
		{
			id: 'documents',
			label: 'Document Library',
			icon: <FileText className='w-5 h-5' />,
		},
		{
			id: 'knowledge',
			label: 'Knowledge Bases',
			icon: <Folder className='w-5 h-5' />,
		},
		{
			id: 'analytics',
			label: 'Analytics',
			icon: <BarChart2 className='w-5 h-5' />,
		},
		{
			id: 'settings',
			label: 'Settings',
			icon: <Settings className='w-5 h-5' />,
		},
	];

	return (
		<div className='flex h-screen bg-gray-50'>
			{/* Sidebar Navigation */}
			<div
				className={`${
					sidebarOpen ? 'w-64' : 'w-20'
				} bg-gray-800 text-white transition-all duration-300 flex flex-col`}
			>
				<div className='p-4 border-b border-gray-700 flex items-center justify-between'>
					{sidebarOpen && <h1 className='text-xl font-bold'>RAG System</h1>}
					<button
						onClick={() => setSidebarOpen(!sidebarOpen)}
						className='p-2 rounded-lg hover:bg-gray-700'
					>
						<ChevronDown
							className={`w-5 h-5 transform ${sidebarOpen ? '' : 'rotate-90'}`}
						/>
					</button>
				</div>

				<nav className='flex-1 py-4'>
					<ul>
						{navItems.map(item => (
							<li key={item.id}>
								<button
									onClick={() => setActiveNav(item.id)}
									className={`flex items-center w-full px-4 py-3 text-left transition-colors ${
										activeNav === item.id ? 'bg-blue-600' : 'hover:bg-gray-700'
									}`}
								>
									<span className='flex-shrink-0'>{item.icon}</span>
									{sidebarOpen && <span className='ml-3'>{item.label}</span>}
								</button>
							</li>
						))}
					</ul>
				</nav>

				{sidebarOpen && (
					<div className='p-4 text-sm text-gray-400 border-t border-gray-700'>
						<p>
							System Status: <span className='text-green-400'>Operational</span>
						</p>
						<p className='mt-1'>
							Documents: <span className='text-white'>24</span>
						</p>
					</div>
				)}
			</div>

			{/* Main Content Area */}
			<div className='flex-1 flex flex-col overflow-hidden'>
				{/* Header */}
				<header className='bg-white border-b border-gray-200 py-3 px-6 flex items-center justify-between'>
					<div className='relative w-96'>
						<div className='absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none'>
							<Search className='text-gray-400 w-5 h-5' />
						</div>
						<input
							type='text'
							placeholder='Search documents, conversations...'
							className='w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500'
						/>
					</div>

					<div className='flex items-center space-x-4'>
						<button className='p-2 text-gray-500 hover:text-gray-700 relative'>
							<Bell className='w-5 h-5' />
							<span className='absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full'></span>
						</button>

						<div className='flex items-center space-x-2'>
							<div className='w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white'>
								<User className='w-5 h-5' />
							</div>
							<span className='text-sm font-medium'>Admin User</span>
						</div>
					</div>
				</header>

				{/* Dynamic Content Area */}
				<main className='flex-1 overflow-auto p-6 bg-gray-50'>
					{activeNav === 'chat' && (
						<div className='flex flex-col h-full'>
							<div className='mb-6'>
								<h2 className='text-2xl font-bold text-gray-800'>
									Chat Interface
								</h2>
								<p className='text-gray-600'>
									Ask questions and get answers from your documents
								</p>
							</div>

							<div className='flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6'>
								{/* Chat Panel */}
								<div className='lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col'>
									<div className='p-4 border-b border-gray-200'>
										<h3 className='font-medium text-gray-800'>Conversation</h3>
									</div>

									<div className='flex-1 p-4 overflow-auto'>
										<div className='space-y-4'>
											{/* Sample conversation */}
											<div className='flex justify-start'>
												<div className='bg-gray-100 rounded-lg p-4 max-w-md'>
													<p className='text-gray-800'>
														What are the main features of our product?
													</p>
												</div>
											</div>

											<div className='flex justify-end'>
												<div className='bg-blue-500 text-white rounded-lg p-4 max-w-md'>
													<p>
														Based on the documents, the main features include:
													</p>
													<ul className='list-disc pl-5 mt-2'>
														<li>Advanced document processing</li>
														<li>Intelligent search capabilities</li>
														<li>Knowledge base management</li>
													</ul>
												</div>
											</div>
										</div>
									</div>

									<div className='p-4 border-t border-gray-200'>
										<div className='flex'>
											<input
												type='text'
												placeholder='Ask a question...'
												className='flex-1 border border-gray-300 rounded-l-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500'
											/>
											<button className='bg-blue-500 text-white px-4 py-2 rounded-r-lg hover:bg-blue-600 transition-colors'>
												Send
											</button>
										</div>
									</div>
								</div>

								{/* Sources Panel */}
								<div className='bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col'>
									<div className='p-4 border-b border-gray-200'>
										<h3 className='font-medium text-gray-800'>Sources</h3>
									</div>

									<div className='flex-1 p-4 overflow-auto'>
										<div className='space-y-3'>
											<div className='p-3 bg-gray-50 rounded-lg border border-gray-200'>
												<div className='flex items-start'>
													<Book className='text-blue-500 mt-1 mr-2 flex-shrink-0 w-5 h-5' />
													<div>
														<h4 className='font-medium text-gray-800'>
															Product Documentation
														</h4>
														<p className='text-sm text-gray-600 mt-1'>
															Relevance: 92%
														</p>
													</div>
												</div>
											</div>

											<div className='p-3 bg-gray-50 rounded-lg border border-gray-200'>
												<div className='flex items-start'>
													<Book className='text-blue-500 mt-1 mr-2 flex-shrink-0 w-5 h-5' />
													<div>
														<h4 className='font-medium text-gray-800'>
															Feature Overview
														</h4>
														<p className='text-sm text-gray-600 mt-1'>
															Relevance: 87%
														</p>
													</div>
												</div>
											</div>

											<div className='p-3 bg-gray-50 rounded-lg border border-gray-200'>
												<div className='flex items-start'>
													<Book className='text-blue-500 mt-1 mr-2 flex-shrink-0 w-5 h-5' />
													<div>
														<h4 className='font-medium text-gray-800'>
															Technical Specifications
														</h4>
														<p className='text-sm text-gray-600 mt-1'>
															Relevance: 75%
														</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					)}

					{activeNav === 'documents' && (
						<div>
							<div className='mb-6'>
								<h2 className='text-2xl font-bold text-gray-800'>
									Document Library
								</h2>
								<p className='text-gray-600'>
									Manage and organize your documents
								</p>
							</div>

							<div className='bg-white rounded-xl shadow-sm border border-gray-200 p-6'>
								<div className='border-2 border-dashed border-gray-300 rounded-lg p-8 text-center mb-6'>
									<FileText className='mx-auto h-12 w-12 text-gray-400' />
									<h3 className='mt-2 text-lg font-medium text-gray-900'>
										Upload Documents
									</h3>
									<p className='mt-1 text-sm text-gray-500'>
										Drag and drop files here, or click to browse
									</p>
									<button className='mt-4 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors'>
										Select Files
									</button>
								</div>

								<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4'>
									{[1, 2, 3, 4, 5, 6].map(item => (
										<div
											key={item}
											className='border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow'
										>
											<div className='flex items-start'>
												<div className='bg-blue-100 p-2 rounded-lg mr-3'>
													<FileText className='text-blue-500 w-6 h-6' />
												</div>
												<div className='flex-1'>
													<h3 className='font-medium text-gray-800'>
														Document {item}
													</h3>
													<p className='text-sm text-gray-600'>PDF • 2.4 MB</p>
													<div className='mt-2 flex items-center'>
														<span className='inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800'>
															Processed
														</span>
													</div>
												</div>
											</div>
										</div>
									))}
								</div>
							</div>
						</div>
					)}

					{activeNav === 'knowledge' && (
						<div>
							<div className='mb-6'>
								<h2 className='text-2xl font-bold text-gray-800'>
									Knowledge Bases
								</h2>
								<p className='text-gray-600'>
									Create and manage document collections
								</p>
							</div>

							<div className='bg-white rounded-xl shadow-sm border border-gray-200 p-6'>
								<div className='flex justify-between items-center mb-6'>
									<h3 className='text-lg font-medium text-gray-800'>
										Your Collections
									</h3>
									<button className='bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors'>
										New Collection
									</button>
								</div>

								<div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
									{[1, 2].map(item => (
										<div
											key={item}
											className='border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow'
										>
											<div className='flex justify-between items-start'>
												<div>
													<h3 className='font-medium text-gray-800'>
														Collection {item}
													</h3>
													<p className='text-sm text-gray-600 mt-1'>
														12 documents • Last updated: Today
													</p>
												</div>
												<button className='text-gray-500 hover:text-gray-700'>
													<Settings className='w-5 h-5' />
												</button>
											</div>

											<div className='mt-4'>
												<div className='flex -space-x-2'>
													{[1, 2, 3, 4].map(doc => (
														<div
															key={doc}
															className='w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 text-xs font-medium border-2 border-white'
														>
															D{doc}
														</div>
													))}
													<div className='w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 text-xs font-medium border-2 border-white'>
														+8
													</div>
												</div>
											</div>
										</div>
									))}
								</div>
							</div>
						</div>
					)}

					{activeNav === 'analytics' && (
						<div>
							<div className='mb-6'>
								<h2 className='text-2xl font-bold text-gray-800'>Analytics</h2>
								<p className='text-gray-600'>
									Monitor system usage and performance
								</p>
							</div>

							<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6'>
								<div className='bg-white rounded-xl shadow-sm border border-gray-200 p-5'>
									<h3 className='text-gray-500 text-sm font-medium'>
										Total Queries
									</h3>
									<p className='text-2xl font-bold text-gray-800 mt-1'>1,248</p>
									<p className='text-green-500 text-sm mt-2'>
										+12% from last week
									</p>
								</div>

								<div className='bg-white rounded-xl shadow-sm border border-gray-200 p-5'>
									<h3 className='text-gray-500 text-sm font-medium'>
										Documents
									</h3>
									<p className='text-2xl font-bold text-gray-800 mt-1'>24</p>
									<p className='text-green-500 text-sm mt-2'>
										+3 new this week
									</p>
								</div>

								<div className='bg-white rounded-xl shadow-sm border border-gray-200 p-5'>
									<h3 className='text-gray-500 text-sm font-medium'>
										Avg. Response Time
									</h3>
									<p className='text-2xl font-bold text-gray-800 mt-1'>1.2s</p>
									<p className='text-green-500 text-sm mt-2'>
										-0.3s improvement
									</p>
								</div>

								<div className='bg-white rounded-xl shadow-sm border border-gray-200 p-5'>
									<h3 className='text-gray-500 text-sm font-medium'>
										Satisfaction Rate
									</h3>
									<p className='text-2xl font-bold text-gray-800 mt-1'>94%</p>
									<p className='text-green-500 text-sm mt-2'>
										+2% from last week
									</p>
								</div>
							</div>

							<div className='bg-white rounded-xl shadow-sm border border-gray-200 p-6'>
								<h3 className='text-lg font-medium text-gray-800 mb-4'>
									Query Activity
								</h3>
								<div className='h-64 bg-gray-50 rounded-lg flex items-center justify-center'>
									<p className='text-gray-500'>
										Analytics chart would be displayed here
									</p>
								</div>
							</div>
						</div>
					)}

					{activeNav === 'settings' && (
						<div>
							<div className='mb-6'>
								<h2 className='text-2xl font-bold text-gray-800'>Settings</h2>
								<p className='text-gray-600'>
									Configure system parameters and models
								</p>
							</div>

							<div className='bg-white rounded-xl shadow-sm border border-gray-200 p-6'>
								<div className='grid grid-cols-1 lg:grid-cols-3 gap-6'>
									<div className='lg:col-span-1'>
										<div className='space-y-1'>
											<button className='w-full text-left px-4 py-2 bg-blue-50 text-blue-700 rounded-lg font-medium'>
												General
											</button>
											<button className='w-full text-left px-4 py-2 hover:bg-gray-50 rounded-lg'>
												LLM Configuration
											</button>
											<button className='w-full text-left px-4 py-2 hover:bg-gray-50 rounded-lg'>
												Embedding Models
											</button>
											<button className='w-full text-left px-4 py-2 hover:bg-gray-50 rounded-lg'>
												Vector Database
											</button>
											<button className='w-full text-left px-4 py-2 hover:bg-gray-50 rounded-lg'>
												API Keys
											</button>
										</div>
									</div>

									<div className='lg:col-span-2'>
										<h3 className='text-lg font-medium text-gray-800 mb-4'>
											General Settings
										</h3>

										<div className='space-y-4'>
											<div>
												<label className='block text-sm font-medium text-gray-700 mb-1'>
													System Name
												</label>
												<input
													type='text'
													defaultValue='RAG System'
													className='w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500'
												/>
											</div>

											<div>
												<label className='block text-sm font-medium text-gray-700 mb-1'>
													Default Language
												</label>
												<select className='w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500'>
													<option>English</option>
													<option>Spanish</option>
													<option>French</option>
													<option>German</option>
												</select>
											</div>

											<div className='flex items-center'>
												<input
													type='checkbox'
													id='analytics'
													defaultChecked
													className='h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500'
												/>
												<label
													htmlFor='analytics'
													className='ml-2 block text-sm text-gray-700'
												>
													Enable analytics collection
												</label>
											</div>

											<div className='pt-4'>
												<button className='bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors'>
													Save Changes
												</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					)}
				</main>
			</div>
		</div>
	);
}
